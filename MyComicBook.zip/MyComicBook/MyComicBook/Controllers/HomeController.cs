﻿using MyComicBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyComicBook.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            ComicBookManager comicBookManager = new ComicBookManager();
            var comicBooks = comicBookManager.GetComicBooks();
            return View(comicBooks);
        }

        public ActionResult Details(int id)
        {
            ComicBookManager comicBookManager = new ComicBookManager();
            var comicBooks = comicBookManager.GetComicBooks();
            var result = comicBooks.FirstOrDefault(g => g.ComicBookId == id);
            return View(result);
        }
    }
}